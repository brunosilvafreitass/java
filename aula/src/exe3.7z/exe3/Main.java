package exe3;

public class Main {
    public static void main(String[] args) {
        ContaPoupanca ContaPoupanca = new ContaPoupanca(0, "null", "null", 0, 0.05);
        ContaCorrente ContaCorrente = new ContaCorrente(2, "Bradesco", "Bruno", 2000, 0.03);
        
        
        ContaPoupanca.depositar(50);
        System.out.println("--------------------");
        ContaPoupanca.sacar(20);
        System.out.println("--------------------");
        ContaCorrente.depositar(50);
        System.out.println("--------------------");
        ContaCorrente.sacar(20);
        System.out.println("--------------------");
        ContaPoupanca.investimento();
        System.out.println("--------------------");
        ContaCorrente.investimento();

    }
}
