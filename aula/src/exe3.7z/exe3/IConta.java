package exe3;

public interface IConta {
    void depositar(double valor);
    void sacar(double valor);
    void investimento();
    void imprimir();
}
