package exe3;

public class ContaPoupanca extends Conta implements IConta {

    public double saldop = 0.05;

    public ContaPoupanca(int numero, String agencia, String titular, double saldo, double saldop) {
        super(numero, agencia, titular, saldo);
        this.saldop = saldop;
    }


    @Override
    public void investimento() {
        depositar(saldo * saldop);
    }


    public double getSaldop() {
        return saldop;
    }




}
