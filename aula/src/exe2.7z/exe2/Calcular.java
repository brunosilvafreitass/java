package exe2;

public abstract class Calcular {
    public abstract double areaq(double lado);
    public abstract double areat(double base, double altura);
    public abstract double areac(double raio);
}
