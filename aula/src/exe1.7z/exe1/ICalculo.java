package exe1;

public interface ICalculo {
    double areaq(double lado);
    double areat(double base, double altura);
    double areac(double raio);
}
