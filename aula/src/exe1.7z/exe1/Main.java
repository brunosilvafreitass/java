package exe1;

public class Main {
    public static void main(String[] args) {
        Calculo calculo = new Calculo();

        System.out.println("quadrado: " + calculo.areaq(4)); 
        System.out.println("triângulo: " + calculo.areat(3, 5)); 
        System.out.println("circunferência: " + calculo.areac(5)); 


    }
    
}
