package exe4;

public interface IDevice {
    void Ligar();
    void Desligar();
    void AumentarVolume();
    void ReduzirVolume();
    void TrocarCanal();
}
